import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getArticles } from "../redux/slices/articleSlice";
import ArticleCard from "../components/ArticleCard";
import CategoryFilter from "../components/CategoryFilter";
import Pagination from "../components/Pagination";
import "../styles/Homepage.css";

const HomePage = () => {
  const dispatch = useDispatch();
  const articles = useSelector((state) => state.articles.articles);
  const status = useSelector((state) => state.articles.status);
  const error = useSelector((state) => state.articles.error);

  const [category, setCategory] = useState("all");
  const [page, setPage] = useState(1);

  useEffect(() => {
    dispatch(getArticles({ category, page }));
  }, [category, page, dispatch]);

  return (
    <div className="home-page">
      <CategoryFilter
        categories={["all", "business", "technology", "entertainment"]}
        currentCategory={category}
        onCategoryChange={setCategory}
      />
      {status === "loading" && <p>Loading...</p>}
      {status === "failed" && <p>{error}</p>}
      <div className="articles-list">
        {articles.map((article) => (
          <ArticleCard key={article.id} article={article} />
        ))}
      </div>
      <Pagination
        currentPage={page}
        totalPages={5} // Assuming 5 pages for simplicity
        onPageChange={setPage}
      />
    </div>
  );
};

export default HomePage;
