import React from "react";
import { Route, Routes } from "react-router-dom";
import HomePage from "./pages/Homepage";
import ArticlePage from "./pages/ArticlePage";
import "./styles/App.css";

const App = () => {
  return (
    <div className="app">
      <Routes>
        <Route exact path="/" component={HomePage} />
        <Route path="/article/:articleId" component={ArticlePage} />
      </Routes>
    </div>
  );
};

export default App;
