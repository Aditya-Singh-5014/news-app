import React from "react";

const Pagination = ({ currentPage, totalPages, onPageChange }) => {
  return (
    <div className="pagination">
      {[...Array(totalPages).keys()].map((number) => (
        <button
          key={number}
          className={currentPage === number + 1 ? "active" : ""}
          onClick={() => onPageChange(number + 1)}
        >
          {number + 1}
        </button>
      ))}
    </div>
  );
};

export default Pagination;
