import axios from "axios";

const BASE_URL = "https://htnewsapi.vercel.app/news";

export const fetchArticles = async (category, page) => {
  try {
    const response = await axios.get(BASE_URL, {
      params: {
        category,
        page,
      },
    });
    return response.data.articles;
  } catch (error) {
    console.error("Error fetching articles: ", error);
    throw error;
  }
};
